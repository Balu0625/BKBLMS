from django.contrib import admin
from .models import *
# Register your models here.

# Register your models here.
admin.site.register(Admin_Cred)
admin.site.register(Books)
admin.site.register(Student_Cred)
admin.site.register(Assigned_Books)
admin.site.register(BooksCount)
admin.site.register(Return_History)
admin.site.register(Book_Pdfs)